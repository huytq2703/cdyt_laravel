-- MySQL dump 10.13  Distrib 8.0.32, for macos13 (x86_64)
--
-- Host: localhost    Database: db_cdyt
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int unsigned DEFAULT NULL,
  `title` varchar(75) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `menu_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_number` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_title_unique` (`title`),
  UNIQUE KEY `categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,15,'HOẠT ĐỘNG CHUYÊN MÔN',NULL,'hoat-dong-chuyen-mon',NULL,'2023-02-10 05:59:16','2023-02-10 05:59:16',NULL,'category','',0),(2,NULL,'Test mới ok ôadf',NULL,'test-moi-ok-oadf',NULL,'2023-02-10 06:41:26','2023-02-19 09:46:31','2023-02-19 09:46:31','category','',0),(3,15,'r',NULL,'r',NULL,'2023-02-10 07:25:54','2023-02-19 09:46:45','2023-02-19 09:46:45','category','',0),(4,NULL,'HOẠT ĐỘNG ĐOÀN THANH NIÊN',NULL,'hoat-dong-doan-thanh-nien',NULL,'2023-02-10 07:26:08','2023-02-10 07:26:08',NULL,'category','',0),(5,NULL,'TIN TỨC NỔI BẬT',NULL,'tin-tuc-noi-bat',NULL,'2023-02-10 07:27:44','2023-02-10 07:27:44',NULL,'category','',0),(6,NULL,'dsfasdfasdfasd',NULL,'dsfasdfasdfasd',NULL,'2023-02-12 19:18:26','2023-02-19 09:46:56','2023-02-19 09:46:56','category','',0),(7,NULL,'fdsafdsafasdfasd',NULL,'fdsafdsafasdfasd',NULL,'2023-02-12 19:18:55','2023-02-19 09:46:54','2023-02-19 09:46:54','category','',0),(8,NULL,'test fda',NULL,'test-fda',NULL,'2023-02-12 19:19:04','2023-02-19 09:44:25','2023-02-19 09:44:25','category','',0),(9,NULL,'Trang chủ',NULL,'trang-chu',NULL,'2023-02-16 09:15:12','2023-02-16 09:15:12',NULL,'menu','system',1),(10,NULL,'Hướng nghiệp',NULL,'huong-nghiep',NULL,'2023-02-16 09:17:02','2023-02-16 09:17:02',NULL,'menu','system',0),(11,NULL,'Hỏi đáp',NULL,'hoi-dap',NULL,'2023-02-16 09:17:52','2023-02-16 09:17:52',NULL,'menu','system',0),(12,NULL,'Liên hệ',NULL,'lien-he',NULL,'2023-02-16 09:18:25','2023-02-16 09:18:25',NULL,'menu','system',2),(13,NULL,'Phòng khoa',NULL,'phong-khoa',NULL,'2023-02-16 09:25:49','2023-02-16 09:25:49',NULL,'menu','dynamic',0),(14,NULL,'Giới thiệu',NULL,'gioi-thieu',NULL,'2023-02-16 09:26:24','2023-02-16 09:26:24',NULL,'menu','dynamic',0),(15,NULL,'Hoạt động nội bộ',NULL,'hoat-dong-noi-bo',NULL,'2023-02-16 09:26:57','2023-02-16 09:26:57',NULL,'menu','dynamic',0),(18,NULL,'Đào tạo',NULL,'dao-tao',NULL,'2023-02-18 03:11:42','2023-02-18 03:11:42',NULL,'menu','system',0),(19,NULL,'Tuyển sinh',NULL,'tuyen-sinh',NULL,'2023-02-18 03:12:27','2023-02-18 03:12:27',NULL,'menu','system',0),(20,NULL,'Sinh viên',NULL,'sinh-vien',NULL,'2023-02-18 03:12:54','2023-02-18 03:12:54',NULL,'menu','system',0),(21,NULL,'Thi và tuyển sinh','Hoạt động thi và tuyển sinh','hoat-dong-thi-va-tuyen-sinh',NULL,'2023-02-18 09:14:15','2023-02-19 09:22:10',NULL,'category','dynamic',0),(22,NULL,'Chương trình đào tạo',NULL,'quan-tri/dao-tao/chuong-trinh-dao-tao',NULL,'2023-02-18 17:50:19','2023-02-18 17:50:19',NULL,'category','system',0),(23,NULL,'Lịch giảng viên',NULL,'quan-tri/dao-tao/lich-giang-vien',NULL,'2023-02-18 17:54:53','2023-02-18 17:54:53',NULL,'category','system',0),(24,NULL,'Test tạo danh mục',NULL,'test-tao-danh-muc',NULL,'2023-02-19 07:12:29','2023-02-19 07:12:29',NULL,'0','dynamic',0),(25,NULL,'Test tạo danh mục mới',NULL,'test-tao-danh-muc-moi',NULL,'2023-02-19 07:13:16','2023-02-19 09:47:00','2023-02-19 09:47:00','category','dynamic',0),(26,NULL,'test',NULL,'test',NULL,'2023-02-19 10:17:06','2023-02-19 10:17:06',NULL,'category','dynamic',0),(28,NULL,'Lịch thi hết môn','Lịch thi hết môn','quan-tri/dao-tao/lich-thi-het-mon',NULL,'2023-02-19 15:19:12','2023-02-19 15:19:12',NULL,'category','system',0),(29,NULL,'Văn bản đào tạo','Văn bản đào tạo','quan-tri/dao-tao/van-ban-dao-tao',NULL,'2023-02-19 15:21:42','2023-02-19 15:21:42',NULL,'category','system',0),(30,NULL,'Thông báo tuyển sinh','Thông báo tuyển sinh','thong-bao',NULL,'2023-02-19 15:56:03','2023-02-19 15:56:03',NULL,'category','system',0),(31,NULL,'Đăng ký trực tuyến','Đăng ký trực tuyến','dang-ky-tuyen-sinh',NULL,'2023-02-19 16:30:49','2023-02-19 16:30:49',NULL,'category','system',0),(32,NULL,'Kết quả tuyển sinh','Kết quả tuyển sinh','ket-qua-tuyen-sinh',NULL,'2023-02-19 16:31:19','2023-02-19 16:31:19',NULL,'category','system',0),(33,NULL,'Tra cứu điểm','Tra cứu điểm','quan-tri/sinh-vien/tra-cuu-diem',NULL,'2023-02-19 16:32:42','2023-02-19 16:32:42',NULL,'category','system',0),(34,NULL,'Tra cứu lịch học','Tra cứu lịch học','quan-tri/sinh-vien/tra-cuu-lich-hoc',NULL,'2023-02-19 16:32:52','2023-02-19 16:32:52',NULL,'category','system',0),(35,NULL,'Tài liệu học tập','Tài liệu học tập','quan-tri/sinh-vien/tai-lieu-hoc-tap',NULL,'2023-02-19 16:33:07','2023-02-19 16:33:07',NULL,'category','system',0),(36,NULL,'Thư viện bài giảng','Thư viện bài giảng','quan-tri/sinh-vien/thu-vien-bai-giang',NULL,'2023-02-19 16:33:23','2023-02-19 16:33:23',NULL,'category','system',0);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-20  0:43:10
