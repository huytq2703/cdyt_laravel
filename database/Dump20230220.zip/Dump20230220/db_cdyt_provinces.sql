-- MySQL dump 10.13  Distrib 8.0.32, for macos13 (x86_64)
--
-- Host: localhost    Database: db_cdyt
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `provinces`
--

DROP TABLE IF EXISTS `provinces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `provinces` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gso_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provinces`
--

LOCK TABLES `provinces` WRITE;
/*!40000 ALTER TABLE `provinces` DISABLE KEYS */;
INSERT INTO `provinces` VALUES (1,'Thành phố Hà Nội','01','2023-02-13 10:27:10','2023-02-13 10:27:10'),(2,'Tỉnh Hà Giang','02','2023-02-13 10:27:10','2023-02-13 10:27:10'),(3,'Tỉnh Cao Bằng','04','2023-02-13 10:27:10','2023-02-13 10:27:10'),(4,'Tỉnh Bắc Kạn','06','2023-02-13 10:27:10','2023-02-13 10:27:10'),(5,'Tỉnh Tuyên Quang','08','2023-02-13 10:27:10','2023-02-13 10:27:10'),(6,'Tỉnh Lào Cai','10','2023-02-13 10:27:10','2023-02-13 10:27:10'),(7,'Tỉnh Điện Biên','11','2023-02-13 10:27:10','2023-02-13 10:27:10'),(8,'Tỉnh Lai Châu','12','2023-02-13 10:27:10','2023-02-13 10:27:10'),(9,'Tỉnh Sơn La','14','2023-02-13 10:27:10','2023-02-13 10:27:10'),(10,'Tỉnh Yên Bái','15','2023-02-13 10:27:10','2023-02-13 10:27:10'),(11,'Tỉnh Hoà Bình','17','2023-02-13 10:27:10','2023-02-13 10:27:10'),(12,'Tỉnh Thái Nguyên','19','2023-02-13 10:27:10','2023-02-13 10:27:10'),(13,'Tỉnh Lạng Sơn','20','2023-02-13 10:27:10','2023-02-13 10:27:10'),(14,'Tỉnh Quảng Ninh','22','2023-02-13 10:27:10','2023-02-13 10:27:10'),(15,'Tỉnh Bắc Giang','24','2023-02-13 10:27:10','2023-02-13 10:27:10'),(16,'Tỉnh Phú Thọ','25','2023-02-13 10:27:10','2023-02-13 10:27:10'),(17,'Tỉnh Vĩnh Phúc','26','2023-02-13 10:27:10','2023-02-13 10:27:10'),(18,'Tỉnh Bắc Ninh','27','2023-02-13 10:27:10','2023-02-13 10:27:10'),(19,'Tỉnh Hải Dương','30','2023-02-13 10:27:10','2023-02-13 10:27:10'),(20,'Thành phố Hải Phòng','31','2023-02-13 10:27:10','2023-02-13 10:27:10'),(21,'Tỉnh Hưng Yên','33','2023-02-13 10:27:10','2023-02-13 10:27:10'),(22,'Tỉnh Thái Bình','34','2023-02-13 10:27:10','2023-02-13 10:27:10'),(23,'Tỉnh Hà Nam','35','2023-02-13 10:27:11','2023-02-13 10:27:11'),(24,'Tỉnh Nam Định','36','2023-02-13 10:27:11','2023-02-13 10:27:11'),(25,'Tỉnh Ninh Bình','37','2023-02-13 10:27:11','2023-02-13 10:27:11'),(26,'Tỉnh Thanh Hóa','38','2023-02-13 10:27:11','2023-02-13 10:27:11'),(27,'Tỉnh Nghệ An','40','2023-02-13 10:27:11','2023-02-13 10:27:11'),(28,'Tỉnh Hà Tĩnh','42','2023-02-13 10:27:11','2023-02-13 10:27:11'),(29,'Tỉnh Quảng Bình','44','2023-02-13 10:27:11','2023-02-13 10:27:11'),(30,'Tỉnh Quảng Trị','45','2023-02-13 10:27:11','2023-02-13 10:27:11'),(31,'Tỉnh Thừa Thiên Huế','46','2023-02-13 10:27:11','2023-02-13 10:27:11'),(32,'Thành phố Đà Nẵng','48','2023-02-13 10:27:11','2023-02-13 10:27:11'),(33,'Tỉnh Quảng Nam','49','2023-02-13 10:27:11','2023-02-13 10:27:11'),(34,'Tỉnh Quảng Ngãi','51','2023-02-13 10:27:11','2023-02-13 10:27:11'),(35,'Tỉnh Bình Định','52','2023-02-13 10:27:11','2023-02-13 10:27:11'),(36,'Tỉnh Phú Yên','54','2023-02-13 10:27:11','2023-02-13 10:27:11'),(37,'Tỉnh Khánh Hòa','56','2023-02-13 10:27:11','2023-02-13 10:27:11'),(38,'Tỉnh Ninh Thuận','58','2023-02-13 10:27:11','2023-02-13 10:27:11'),(39,'Tỉnh Bình Thuận','60','2023-02-13 10:27:11','2023-02-13 10:27:11'),(40,'Tỉnh Kon Tum','62','2023-02-13 10:27:11','2023-02-13 10:27:11'),(41,'Tỉnh Gia Lai','64','2023-02-13 10:27:11','2023-02-13 10:27:11'),(42,'Tỉnh Đắk Lắk','66','2023-02-13 10:27:11','2023-02-13 10:27:11'),(43,'Tỉnh Đắk Nông','67','2023-02-13 10:27:11','2023-02-13 10:27:11'),(44,'Tỉnh Lâm Đồng','68','2023-02-13 10:27:11','2023-02-13 10:27:11'),(45,'Tỉnh Bình Phước','70','2023-02-13 10:27:11','2023-02-13 10:27:11'),(46,'Tỉnh Tây Ninh','72','2023-02-13 10:27:11','2023-02-13 10:27:11'),(47,'Tỉnh Bình Dương','74','2023-02-13 10:27:11','2023-02-13 10:27:11'),(48,'Tỉnh Đồng Nai','75','2023-02-13 10:27:11','2023-02-13 10:27:11'),(49,'Tỉnh Bà Rịa - Vũng Tàu','77','2023-02-13 10:27:11','2023-02-13 10:27:11'),(50,'Thành phố Hồ Chí Minh','79','2023-02-13 10:27:11','2023-02-13 10:27:11'),(51,'Tỉnh Long An','80','2023-02-13 10:27:11','2023-02-13 10:27:11'),(52,'Tỉnh Tiền Giang','82','2023-02-13 10:27:11','2023-02-13 10:27:11'),(53,'Tỉnh Bến Tre','83','2023-02-13 10:27:11','2023-02-13 10:27:11'),(54,'Tỉnh Trà Vinh','84','2023-02-13 10:27:11','2023-02-13 10:27:11'),(55,'Tỉnh Vĩnh Long','86','2023-02-13 10:27:11','2023-02-13 10:27:11'),(56,'Tỉnh Đồng Tháp','87','2023-02-13 10:27:11','2023-02-13 10:27:11'),(57,'Tỉnh An Giang','89','2023-02-13 10:27:11','2023-02-13 10:27:11'),(58,'Tỉnh Kiên Giang','91','2023-02-13 10:27:12','2023-02-13 10:27:12'),(59,'Thành phố Cần Thơ','92','2023-02-13 10:27:12','2023-02-13 10:27:12'),(60,'Tỉnh Hậu Giang','93','2023-02-13 10:27:12','2023-02-13 10:27:12'),(61,'Tỉnh Sóc Trăng','94','2023-02-13 10:27:12','2023-02-13 10:27:12'),(62,'Tỉnh Bạc Liêu','95','2023-02-13 10:27:12','2023-02-13 10:27:12'),(63,'Tỉnh Cà Mau','96','2023-02-13 10:27:12','2023-02-13 10:27:12');
/*!40000 ALTER TABLE `provinces` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-20  0:43:10
